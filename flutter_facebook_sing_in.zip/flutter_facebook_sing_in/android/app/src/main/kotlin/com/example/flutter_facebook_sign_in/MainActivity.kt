package com.example.flutter_facebook_sign_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
