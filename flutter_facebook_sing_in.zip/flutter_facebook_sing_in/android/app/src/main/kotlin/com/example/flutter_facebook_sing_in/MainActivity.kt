package com.example.flutter_facebook_sing_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
